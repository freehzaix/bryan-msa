<?php $__env->startSection('title'); ?>
    Connexion
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="ftco-section">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-10">
                    <div class="wrap d-md-flex">
                        <div class="img" style="background-image: url(/frontend/Assets/images/msa-register-img.jpg);">
                        </div>
                        <div class="login-wrap p-4 p-md-5">
                            <div class="d-flex">
                                <div class="w-100">
                                    <h3 class="mb-4">Se connecter </h3>
                                </div>
                                <div class="w-100">
                                    <p class="social-media d-flex justify-content-end">
                                        <a href="/login"
                                            class="social-icon d-flex align-items-center justify-content-center">
                                            <span class="fa fa-arrow-left" aria-hidden="true"></span>
                                        </a>
                                    </p>
                                </div>

                            </div>

                            <?php if($errors->any()): ?>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="alert alert-danger">
                                            <?php echo e($error); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>

                            <form action="/login/traitement" method="POST" class="signin-form">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label class="label" for="email">Email</label>
                                    <input type="text" class="form-control" name="email"
                                        placeholder="Entrez votre mail" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label" for="password">Mot de passe </label>
                                    <input type="password" class="form-control" name="motdepasse"
                                        placeholder="Entrez votre Mot de passe" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="form-control btn btn-primary rounded submit px-3">Se
                                        connecter</button>
                                </div>

                            </form>

                            <p class="text-center">Pas encore membre? <a href="/register" target="_parent">S'inscrire</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bryan-dele\resources\views/login.blade.php ENDPATH**/ ?>