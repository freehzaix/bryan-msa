
## Projet Laravel MSA

Le projet n'est pas encore terminer.
- J'ai déjà fini le formulaire d'inscription
- J'ai fini le formulaire de connexion
- J'ai fini la page de déconnexion
- J'ai fini d'afficher les information de l'espace membre

Instruction: je t'ai envoyer une base de données par mail. Insert le nom de la base de données de le fichier .env.
Et importe le script de ma base de données dans ta base de données sur ton ordi.

Pour démarrer un projet Laravel, utilise la commande: 
- php artisan serve

Mais il faut que le serveur Apache et MySQL soit démarré.
