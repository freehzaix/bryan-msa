-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 26 jan. 2023 à 11:42
-- Version du serveur : 10.4.25-MariaDB
-- Version de PHP : 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `msa_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `colonnes`
--

CREATE TABLE `colonnes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `colonne_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colonne_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `colonnes`
--

INSERT INTO `colonnes` (`id`, `colonne_code`, `colonne_name`, `created_at`, `updated_at`) VALUES
(1, 'col1', 'Shalom', '2023-01-24 13:41:33', '2023-01-24 13:41:33'),
(2, 'col2', 'Achija', '2023-01-24 14:13:44', '2023-01-24 14:13:44'),
(3, 'col3', 'Eli', '2023-01-24 14:32:07', '2023-01-24 14:32:07'),
(4, 'col4', 'Art', '2023-01-24 14:32:23', '2023-01-24 14:32:23'),
(5, 'col5', 'Adec', '2023-01-24 14:32:40', '2023-01-24 14:32:40'),
(6, 'col6', 'Ezer', '2023-01-24 14:33:00', '2023-01-24 14:33:00'),
(7, 'col7', 'Shofar', '2023-01-24 14:33:18', '2023-01-24 14:33:18');

-- --------------------------------------------------------

--
-- Structure de la table `departements`
--

CREATE TABLE `departements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `departement_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departement_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colonne_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `departements`
--

INSERT INTO `departements` (`id`, `departement_code`, `departement_name`, `colonne_id`, `created_at`, `updated_at`) VALUES
(1, 'dep1', 'Accueil', 1, '2023-01-24 14:10:36', '2023-01-24 14:10:36'),
(2, 'dep2', 'Potiers', 1, '2023-01-24 14:12:49', '2023-01-24 14:12:49'),
(3, 'dep3', 'Jonathan', 1, '2023-01-24 14:13:10', '2023-01-24 14:13:10'),
(4, 'dep1', 'Logistique & Technique', 2, '2023-01-24 14:34:29', '2023-01-24 14:34:29'),
(5, 'dep2', 'Cleaning', 2, '2023-01-24 14:34:57', '2023-01-24 14:34:57'),
(6, 'dep3', 'Decoration', 2, '2023-01-24 14:35:25', '2023-01-24 14:35:25'),
(7, 'dep4', 'Transport', 2, '2023-01-24 14:35:48', '2023-01-24 14:35:48'),
(8, 'dep1', 'Gethsemané', 3, '2023-01-24 14:36:26', '2023-01-24 14:36:26'),
(9, 'dep2', 'PDG', 3, '2023-01-24 14:36:45', '2023-01-24 14:36:45'),
(10, 'dep1', 'Prophète musiciens', 4, '2023-01-24 14:37:42', '2023-01-24 14:37:42'),
(11, 'dep2', 'Les Davids', 4, '2023-01-24 14:38:05', '2023-01-24 14:38:05'),
(12, 'dep3', 'Les teams bulder', 4, '2023-01-24 14:38:42', '2023-01-24 14:38:42'),
(13, 'dep1', 'Finance', 5, '2023-01-24 14:39:32', '2023-01-24 14:39:32'),
(14, 'dep2', 'Event planer', 5, '2023-01-24 14:39:54', '2023-01-24 14:39:54'),
(15, 'dep3', 'Statistiques', 5, '2023-01-24 14:40:31', '2023-01-24 14:40:31'),
(16, 'dep4', 'Juridique', 5, '2023-01-24 14:41:04', '2023-01-24 14:41:04'),
(17, 'dep6', 'Formation & orientation', 5, '2023-01-24 14:41:57', '2023-01-24 14:41:57'),
(18, 'dep7', 'Bibliothèque numérique', 5, '2023-01-24 14:42:28', '2023-01-24 14:42:28'),
(19, 'dep1', 'Jésus pour les enfants', 6, '2023-01-24 14:43:27', '2023-01-24 14:43:27'),
(20, 'dep2', 'Jésus pour les ados', 6, '2023-01-24 14:44:06', '2023-01-24 14:44:06'),
(21, 'dep3', 'Ezer pour les célibataires & mariés', 6, '2023-01-24 14:44:47', '2023-01-24 14:44:47'),
(22, 'dep4', 'Santé', 6, '2023-01-24 14:45:13', '2023-01-24 14:45:13'),
(23, 'dep1', 'Production Audiovisuel', 7, '2023-01-24 14:45:52', '2023-01-24 14:45:52'),
(24, 'dep2', 'Call center', 7, '2023-01-24 14:46:49', '2023-01-24 14:46:49'),
(25, 'dep3', 'Community management', 7, '2023-01-24 14:47:27', '2023-01-24 14:47:27'),
(26, 'dep4', 'Interprétariat', 7, '2023-01-24 14:48:02', '2023-01-24 14:48:02'),
(27, 'dep5', 'Annonce', 7, '2023-01-24 14:48:20', '2023-01-24 14:48:20');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

CREATE TABLE `membres` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `motdepasse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quartier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colonne` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departement` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/frontend/Assets/images/no-image.png',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_01_24_110052_create_membres_table', 1),
(6, '2023_01_24_130203_create_colonnes_table', 1),
(7, '2023_01_24_130300_create_departements_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `colonnes`
--
ALTER TABLE `colonnes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `departements`
--
ALTER TABLE `departements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `departements_colonne_id_foreign` (`colonne_id`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `membres_email_unique` (`email`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `colonnes`
--
ALTER TABLE `colonnes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `departements`
--
ALTER TABLE `departements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `membres`
--
ALTER TABLE `membres`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `departements`
--
ALTER TABLE `departements`
  ADD CONSTRAINT `departements_colonne_id_foreign` FOREIGN KEY (`colonne_id`) REFERENCES `colonnes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
